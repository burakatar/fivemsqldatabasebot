# Hoşgeldiniz!

Merhaba ben Itami, bildiğiniz üzere FiveM'de eğer güzel bir panele sahip değilseniz veya yetkililerinize güven sonucunda sıkıntı yaşıyorsanız bunun çözümünü farklı bir database editor ile bulmanız gerekiyor. Projemizdeki komutları kendi databasenize göre editleyerek Discord üzerinden sunucunuzdaki birçok eylemi gerçekleştirebilirsiniz. İster kafede  ister telefonda!


# Kurulum

Ayarlar.json klasöründen kendi prefix token ve ayarlarınızı yapmanız gerekmekte, ardından komutlar klasöründe komutları kendi database bilginize göre editleyerek **prefixiniz!yetkiler** komutu ile komutlara ulaşabilirsiniz!

## Gerekenler

Node.js 
